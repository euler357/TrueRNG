TrueRNGpro Windows Driver

1. Right-click on the TrueRNGpro.inf file
2. Choose install
3. Plug device into a USB port 

It will be auto-installed and show up as a COM port in Device Manager

